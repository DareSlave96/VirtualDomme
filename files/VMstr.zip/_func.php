<?php
	function GetMenu (){
		return "	<a href='tasks.php'>Tasks</a><br>
					<a href='punishments.php'>Punishments</a><br>
					<a href='rewards.php'>Rewards</a><br>
					<a href='sessions.php'>Sessions</a><br>
					<a href='details.php'>Sign In / Up</a><br>";
	}
	function GetQuote (){
		// Returns a random quote from DB.
		$db = new PDO('sqlite:_DB.sqlite');
		$res = $db -> query('SELECT count(*) FROM `Quotes` WHERE 1'); 
		$max = $res -> fetchColumn();
		$quote = rand(1, $max);
		$qry = "SELECT * FROM `Quotes` WHERE `ID` = $quote";
		foreach ($db -> query( $qry ) as $row) {
			$quote = $row['Quote'];
			$auth =  $row['Author'];
		}		
		return $quote;
	}
	function GetPunPnt (){
		// Returns the various points from DB.
		return 0;
	} 
	function GetRewPnt (){
		// Returns the various points from DB.
		return 0;
	} 
	function GetTasPnt (){
		// Returns the various points from DB.
		return 0;
	}
	function GetNews (){
		// Fetches and returns the news.
		
	}
	function GetTask (){
		// And returns a random task that user has to complete.
		
	}
	function GetPun (){
		// Fetches and returns a random punishment based on how many punishment points user has.
		
	}
	function GetPlea (){
		// Fetches and returns a random reward based on both how many punishment and how many reward/loyalty points the user has.
		
	}
	function GetSes (){
		// Fetches and returns a random session (html file) that the user can complete located in 'res/ses/'
		
	}